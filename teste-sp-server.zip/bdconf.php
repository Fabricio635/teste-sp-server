<?php

$host = "sql304.epizy.com";
$port = "3306";
$conn = @mysql_connect($host, "epiz_20767288", "OjdkxIneh6") or die (mysql_error());
$conn = mysql_select_db("epiz_20767288_testesp", $conn)  or die ('Não foi possivel conectar ao banco de dados...');

/*$host = getenv(strtoupper(getenv("DATABASE_SERVICE_NAME"))."_SERVICE_HOST");
$port = getenv(strtoupper(getenv("DATABASE_SERVICE_NAME"))."_SERVICE_PORT");
$conn = @mysql_connect("$host:$port", getenv("DATABASE_USER"), getenv("DATABASE_PASSWORD")) or die (mysql_error());
$conn = mysql_select_db(getenv("DATABASE_NAME"), $conn)  or die ('Não foi possivel conectar ao banco de dados...');*/

?>